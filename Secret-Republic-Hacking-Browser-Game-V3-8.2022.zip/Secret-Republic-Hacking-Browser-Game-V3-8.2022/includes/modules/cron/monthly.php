<?php

	

$type = "monthly";

$report = "Monthly Cron ".date("d/F/Y H:i:s", $runTime);


//$db->rawQuery('update users set alphaCoins = alphaCoins + 5');

$report .= sprintf("\nGave A-Coins to players");



