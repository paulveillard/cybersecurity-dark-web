# templates

Smarty template files for all pages.
